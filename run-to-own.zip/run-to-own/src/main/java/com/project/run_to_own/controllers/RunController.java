package com.project.run_to_own.controllers;

import com.project.run_to_own.model.Run;
import com.project.run_to_own.model.User;
import com.project.run_to_own.repositories.RunRepository;
import com.project.run_to_own.repositories.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Sort;
import java.util.List;
import java.time.LocalDateTime;


@Controller
public class RunController {

    @Autowired
    private RunRepository runRepository;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/home")
    public String showHome(Model model, HttpSession session) {
        String email = (String) session.getAttribute("email");
        if (email == null) {
            return "redirect:/login";
        }

        User user = userRepository.findByEmail(email);
        List<Run> runs = runRepository.findByUserEmail(email); // Make sure this method exists
        model.addAttribute("runs", runs);

        return "home";
    }


    @GetMapping("/api/runs")
    @ResponseBody
    public List<Run> getAllRuns(HttpSession session) {
        String email = (String) session.getAttribute("email");
        User user = userRepository.findByEmail(email);
        return runRepository.findByUser(user);
    }



    @GetMapping("/runs")
    public String showAllRuns(Model model) {
        List<Run> runs = runRepository.findAll(Sort.by(Sort.Direction.DESC, "timestamp"));
        model.addAttribute("runs", runs);
        return "home";
    }


    @GetMapping("/run")
    public String showRunForm(Model model) {
        model.addAttribute("run", new Run());
        return "run";
    }

    @PostMapping("/run")
    public String submitRun(@ModelAttribute Run run, HttpSession session) {
        String email = (String) session.getAttribute("email");
        User user = userRepository.findByEmail(email);

        run.setUser(user);
        run.setTimestamp(LocalDateTime.now());  // ❗ Make sure to import java.time.LocalDateTime
        runRepository.save(run);

        return "redirect:/profile";
    }

    @PostMapping("/runs")
    public String submitRun(
            @RequestParam String route,
            @RequestParam double distance,
            @RequestParam double latitude,
            @RequestParam double longitude,
            HttpSession session
    ) {
        String email = (String) session.getAttribute("email");
        User user = userRepository.findByEmail(email);

        Run run = new Run();
        run.setRoute(route);
        run.setDistance(distance);
        run.setLatitude(latitude);
        run.setLongitude(longitude);
        run.setUser(user);
        run.setTimestamp(LocalDateTime.now());

        runRepository.save(run);

        return "redirect:/profile";
    }

}
