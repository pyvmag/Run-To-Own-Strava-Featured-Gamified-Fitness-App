package com.project.run_to_own.controllers;

import com.project.run_to_own.model.User;
import com.project.run_to_own.model.Run;
import com.project.run_to_own.repositories.RunRepository;
import com.project.run_to_own.repositories.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class ProfileController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RunRepository runRepository;

    @GetMapping("/profile")
    public String showProfile(Model model, HttpSession session) {
        String currentUserEmail = (String) session.getAttribute("email");
        if (currentUserEmail == null) {
            return "redirect:/login";
        }

        User user = userRepository.findByEmail(currentUserEmail);
        List<Run> runs = runRepository.findByUserEmail(currentUserEmail);

        model.addAttribute("user", user);
        model.addAttribute("runs", runs);

        return "profile";
    }
}
