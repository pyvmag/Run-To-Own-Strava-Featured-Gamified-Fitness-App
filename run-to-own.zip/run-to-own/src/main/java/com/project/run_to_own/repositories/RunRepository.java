package com.project.run_to_own.repositories;

import com.project.run_to_own.model.Run;
import com.project.run_to_own.model.User; // ✅ MAKE SURE THIS IS IMPORTED
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface RunRepository extends JpaRepository<Run, Long> {
    List<Run> findByUser(User user);
    // RunRepository.java
    List<Run> findByUserEmail(String email);
// ✅ User from your model package
}
