package com.project.run_to_own.controllers;

import com.project.run_to_own.model.User;
import com.project.run_to_own.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class SignupController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/signup")
    public String showForm(Model model) {
        model.addAttribute("user", new User());
        return "signup";
    }

    @PostMapping("/signup")
    public String signupSubmit(@ModelAttribute User user, Model model) {
        userRepository.save(user);
        model.addAttribute("message", "Signup successful for: " + user.getUsername());
        return "signup";
    }
}
