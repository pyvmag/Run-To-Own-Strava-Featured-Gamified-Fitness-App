package com.project.run_to_own.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;
@Entity
@Table(name = "runs")
public class Run {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String route;
    private double distance;
    private LocalDateTime timestamp = LocalDateTime.now();
    @ElementCollection
    private List<Double> latitudes;

    @ElementCollection
    private List<Double> longitudes;

    @ManyToOne
    private User user;
    @JoinColumn(name = "user_id")

    @Column
    private Double latitude;

    @Column
    private Double longitude;

    // Add getters and setters:
    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    // Getters & Setters
    public Long getId() { return id; }

    public String getRoute() { return route; }
    public void setRoute(String route) { this.route = route; }

    public double getDistance() { return distance; }
    public void setDistance(double distance) { this.distance = distance; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}
