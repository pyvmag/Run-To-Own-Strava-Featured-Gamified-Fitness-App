//package com.project.run_to_own.dto;
//
//public class TileDTO {
//    private String id;
//    private String ownerName;
//    private int x;
//    private int y;
//    private String tileColor;
//
//    public TileDTO() {}
//
//    public TileDTO(String id, String ownerName, int x, int y, String tileColor) {
//        this.id = id;
//        this.ownerName = ownerName;
//        this.x = x;
//        this.y = y;
//        this.tileColor = tileColor;
//    }
//
//    public String getId() { return id; }
//    public void setId(String id) { this.id = id; }
//
//    public String getOwnerName() { return ownerName; }
//    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }
//
//    public int getX() { return x; }
//    public void setX(int x) { this.x = x; }
//
//    public int getY() { return y; }
//    public void setY(int y) { this.y = y; }
//
//    public String getTileColor() { return tileColor; }
//    public void setTileColor(String tileColor) { this.tileColor = tileColor; }
//}