//package com.project.run_to_own.repositories;
//
//import com.project.run_to_own.model.RunnerOwnership;
//import org.springframework.data.jpa.repository.JpaRepository;
//import java.util.List;
//
//public interface RunnerOwnershipRepository extends JpaRepository<RunnerOwnership, Long> {
//    List<RunnerOwnership> findByRunnerId(String runnerId);
//}