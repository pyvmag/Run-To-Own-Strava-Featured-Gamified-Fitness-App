package com.project.run_to_own;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RunToOwnApplication {

	public static void main(String[] args) {
		SpringApplication.run(RunToOwnApplication.class, args);
	}

}
