//package com.project.run_to_own.repositories;
//
//import com.project.run_to_own.model.Tile;
//import org.springframework.data.jpa.repository.JpaRepository;
//import java.util.List;
//
//public interface TileRepository extends JpaRepository<Tile, String> {
//    List<Tile> findByOwnerId(String ownerId);
//}